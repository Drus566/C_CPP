#include "metropolis.h"

Metropolis::Metropolis(int _x, int _y, int _square, int _population) : Area(_x, _y, _square)
{
	population = _population;
}
