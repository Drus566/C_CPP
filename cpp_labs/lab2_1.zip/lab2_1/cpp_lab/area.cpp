#include "area.h"

Area::Area(int _x, int _y, int _square) : Place()
{
 	x = _x;
 	y = _y;
	square = _square;
}
